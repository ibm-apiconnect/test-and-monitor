  <tr>
    <td> Stop test if fails </td>
    <td> Selection list </td>
    <td> No </td>
    <td> Select <code>true</code> or <code>false</code>. If <code>true</code>, the test is immediately stopped if the assertion fails. </td>
    <td> False </td>
  </tr>
