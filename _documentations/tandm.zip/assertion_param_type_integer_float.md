<tr>
    <td> Type </td>
    <td> Selection list </td>
    <td> No </td>
    <td> The data type of the value. If you do not specify a data type, the values are compared as strings. Select one of the following values:
      <ul>
        <li><code>integer</code>: the values are evaluated as whole numbers.</li>
        <li><code>float</code>: the values are evaluated as decimal numbers.</li>
      </ul>
    </td>
    <td> Integer </td>
</tr>
