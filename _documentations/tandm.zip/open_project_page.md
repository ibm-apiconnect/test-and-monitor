1. Click your test organization name in the menu bar to open your test organization project page.
  
    ![Image of test organization name](./dist/images/test-org-name-in-menu-bar.png) 
