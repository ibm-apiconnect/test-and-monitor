<tr>
    <td> Modifier </td>
    <td> Selection list </td>
    <td> No </td>
    <td> Select <code>not</code> to negate the assertion; the assertion is considered verified if it does not pass. </td>
    <td> None </td>
</tr>
