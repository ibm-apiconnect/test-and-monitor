---
layout: docs
title: Security
description: Security
keywords: security, personal information, PI
duration: 1 minute
permalink: security
type: document
order: 20
parent: root
---

It is important to be aware of potential security implications when using IBM API Connect Test and Monitor:
  
- [Storing Sensitive Data](./storing-sensitive-data)
