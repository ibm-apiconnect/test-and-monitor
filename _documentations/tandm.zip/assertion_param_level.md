<tr>
    <td> Level </td>
    <td> Selection list </td>
    <td> No </td>
    <td> Select <code>error</code> or <code>warning</code>. Specifies whether, if the assertion fails, it should be considered an ‘error’ or just a ‘warning.’ A warning does not trigger alerts, such as email or text messages. </td>
    <td>Error</td>
</tr>
