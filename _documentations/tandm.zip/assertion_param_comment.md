<tr>
    <td> Assertion comment </td>
    <td> String </td>
    <td> No </td>
    <td> An optional comment for information. </td>
    <td></td>
</tr>
