<tr>
    <td> Mode </td>
    <td> Selection list </td>
    <td> No </td>
    <td> Select one of the following values:
      <ul>
        <li> <code>all</code>: If the path expression matches multiple elements in the payload then they must all match the assertion.</li>
        <li> <code>one</code>: Only one of the matching elements in the payload needs to match the assertion.</li>
      </ul>
   </td>
   <td> All </td>
</tr>
