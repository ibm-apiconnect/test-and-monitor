## Local microclimate deployment

#### Prerequisites
* [Docker](https://www.docker.com/get-docker) **v17.06 minimum**
* Linux only: follow post-installation steps to
  * [Run docker as a non-root user](https://docs.docker.com/engine/installation/linux/linux-postinstall/)
  * [Update docker-compose](https://docs.docker.com/compose/install/)

#### Install and run


1. Unzip the downloaded file from the download link on the front page.

2. Install the microclimate command line interface (mcdev).


##### Linux/MacOS  
Non-sudo installation (Run as ~/mcdev or manually add to path)
```
cd cli
./install.sh
cd ..
```
Sudo user installation (install as root and to `/usr/local/bin` automatically putting it on your path)
```
cd cli
sudo ./install.sh
cd ..
```
NOTE: You won't be able to run `mcdev` commands from inside the cli directory due to the file name conflict. To run commands change to another directory.
##### For Windows, PowerShell (.ps1)
In a PowerShell session run
```
cli\install.ps1
```
3. Run the following command to start and open microclimate.
```
mcdev start -o
```


### Stopping

1. To stop Microclimate just run the command:
```
mcdev stop
```
This will stop and remove your Microclimate Docker containers.
