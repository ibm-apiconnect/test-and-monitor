
#*******************************************************************************
# Licensed Materials - Property of IBM
# "Restricted Materials of IBM"
#
# Copyright IBM Corp. 2017 All Rights Reserved
#
# US Government Users Restricted Rights - Use, duplication or disclosure
# restricted by GSA ADP Schedule Contract with IBM Corp.
#*******************************************************************************

"*****************************************************"
"**          Running Microclimate installer         **"
"*****************************************************"

#if (!(Test-Path $home\microclimate_workspace)) {
#    ""
#    "Creating microclimate workspace"
#    New-Item $home\microclimate_workspace -type directory
#}

# TODO - check whether microclimate CLI is already on the user's PATH

""
"Adding microclimate CLI (mcdev command) to your PATH"
if (!($env:path.EndsWith(";"))) {
    $env:path += ";" # add separator to user's path
}
$env:path += Split-Path -parent $PSCommandPath
$env:path += ";"
""
"Run 'mcdev help' for usage instructions"
""